<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<h1>Dove Forums Installer</h1>
<div class="page_list">
    <div class="general">
    <div class="general_inner_border">
        <h3><?php echo $this->lang->line('step2Title'); ?></h3>
        <p><?php echo $this->lang->line('step2Text'); ?></p>
        
        <div class="buttons">
            <div class="smallButton"><div class="pageButton"><div class="content"><?php echo ''.anchor('forums/', 'Finish').''; ?></div></div></div>       
        </div>      
    </div>
    </div>
</div>